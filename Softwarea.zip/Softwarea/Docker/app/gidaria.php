<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=P, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <H1>KAIXO GIDARIA NAIZ!</H1>
</body>
</html>